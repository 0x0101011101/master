console.log("Reading Files");

// Loading FS module
var fs = require('fs');

fs.readFile("DirectoryA/fileA.txt", "utf8", function(err,data) { // 2nd arg for // Asynchronous function

	if(err) {
		console.log(err);
	}
	else {
		console.log(data);
	}
});

// Synchronous way
var contents = fs.readFileSync("DirectoryA/fileA.txt", "utf8");

console.log(contents);