console.log("Watching for Directory changes");

// Loading FS module
var fs = require('fs');

// watch method depend on underlying operation system
fs.watch("DirectoryA", {persistent:true}, function(event,filename) { // persistent:true > continuously watch 4 changes // default value
																	 // event : rename, delete,..
		if(event == "rename") {										 // filename : file concerned
			console.log("RENAME Event in Directory : " + filename);
		}
		
		if(event == "change") {
			console.log("CHANGE Event in Directory : " + filename);
		}
}); 
																	
																	