console.log("Watching for File changes");

// Loading FS module
var fs = require('fs');

// File to watch
var nameOfFile = "DirectoryA/myTestFile.txt";

/*
// watch method depend on underlying operation system
fs.watch(nameOfFile, {persistent:true}, function(event,filename) { // persistent:true > continuously watch 4 changes // default value
																   // event : rename, delete,..
																   // filename : file concerned
		console.log("CHANGE Event in watched file : " + nameOfFile);
		
}); 
*/
	
// watchFile method depend on underlying operation system (verify all stats of fille, little bit slow
fs.watchFile(nameOfFile, {persistent:true, interval:5000}, function(event,filename) { // persistent:true > continuously watch 4 changes // default value
																   // event : rename, delete,..
																   // filename : file concerned
			console.log("CHANGE Event in watched file : " + nameOfFile);
		
}); 																	