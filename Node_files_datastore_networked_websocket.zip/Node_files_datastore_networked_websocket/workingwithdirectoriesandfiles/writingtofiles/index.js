console.log("Writing Files");

// Loading FS module
var fs = require('fs');

var data = "This is a string i am writing to file";
var data2 = "A second string appending";

fs.writeFile("DirectoryA/myTestFile.txt", data, function(err) { // Asynchronous method
	
	if(err) {
		console.log(err);
	}
	else {
		console.log("Data saved to file");
	}
});

fs.appendFile("DirectoryA/myTestFile.txt", data2, function(err) { // Asynchronous method
	
	if(err) {
		console.log(err);
	}
	else {
		console.log("Data appended to file");
	}
});