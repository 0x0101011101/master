console.log("Adding and Removing Directories");

// Loading FS module
var fs = require('fs');

/*
// Create subfolder DirectoryB
fs.mkdir('DirectoryA/DirectoryB', function(err) {
	
	if (err) {
		console.log(err);
	}
	else {
		console.log("Directory created");
	}
});
*/

// Delete subfolder DirectoryB
fs.rmdir('DirectoryA/DirectoryB', function(err) {
	
	if (err) {
		console.log(err);
	}
	else {
		console.log("Directory deleted");
	}
});