console.log("Creating TCP Client Application");


// Loading NET Module
var net = require('net');

// Create object
var options = {
	port:4567,
	host:"localhost"
};

//
var demoClientName = "myUniqueClientID";

// Creating Socket
var clientSocket = net.connect(options)

// Listen to connect event emitted by socket
clientSocket.on('connect', function() {
	console.log("Client connected successfully");
	
	var message = "I am client w/ address " + demoClientName + "\r\n";
	
	// Send message to Server
	var dataSent = clientSocket.write(message, 'utf8', function() {
		console.log("Data was written out");
		console.log("Data sent to Server : " + clientSocket.bytesWritten);
	});
	
	// Is buffer empty ?
	clientSocket.on('drain', function() {
		console.log("Buffer completely empty");
	});
	
	// Receive data from Server
	clientSocket.on('data', function(data) {
		console.log("Data received from Server : " + data);
		console.log("Data read from Server : " + clientSocket.bytesRead);
	});
	
});