console.log("Creating TCP Server Using the Net Module");

// Loading NET Module
var net = require('net');

// Create TCP Server
var server = net.createServer();

// Create Tracked Client 
var trackedClient;

// Other client has connected to it ?
server.on('connection', function(socket) {  // connection is the Event connection
	
	trackedClient = socket;

	console.log("TCP Server has received a connection");
	
	socket.write("Welcome, You are connected\r\n");
	
	// Listening for 'data' event
	socket.on('data', function(data) {
		console.log("Server received some data : ", data.toString());
		if (trackedClient) trackedClient.write("Thanks for saying hi\r\n");
	});
});

// Listening
var port = 4567;
server.listen(port, function() {
	console.log("TCP Server Listening on port : " + port);
});