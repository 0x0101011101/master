console.log("Creating TCP Client Application");


// Loading NET Module
var net = require('net');

// Create object
var options = {
	port:3456,
	host:"localhost"
};

// Creating Socket
var clientSocket = net.connect(options)

// Listen to connect event emitted by socket
clientSocket.on('connect', function() {
	console.log("Client connected successfully");
});