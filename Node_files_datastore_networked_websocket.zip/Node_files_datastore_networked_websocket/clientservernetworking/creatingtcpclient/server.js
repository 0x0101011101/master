console.log("Creating TCP Server Using the Net Module");


// Loading NET Module
var net = require('net');

// Create TCP Server
var server = net.createServer();

// Number of connection
var numConnections = 0;

// Other client has connected to it ?
server.on('connection', function(socket) {  // connection is the Event connection
	console.log("TCP Server has receive a connection");
	
	numConnections++;
	
	socket.write("Welcome. There are " + numConnections + " active connections");
});

// Listening
var port = 3456;
server.listen(port, function() {
	console.log("TCP Server Listening");
});