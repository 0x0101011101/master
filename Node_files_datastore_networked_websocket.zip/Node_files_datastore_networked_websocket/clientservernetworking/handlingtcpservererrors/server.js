console.log("Creating TCP Server Using the Net Module");

// Loading NET Module
var net = require('net');

// Create TCP Server
var server = net.createServer();

// Create Tracked Client 
var trackedClient;

// Other client has connected to it ?
server.on('connection', function(socket) {  // connection is the Event connection
	
	trackedClient = socket;

	console.log("TCP Server has received a connection");
	
	socket.write("Welcome, You are connected\r\n");
	
	// Listening for 'data' event
	socket.on('data', function(data) {
		console.log("Server received some data : ", data.toString());
		if (trackedClient) trackedClient.write("Thanks for saying hi\r\n");
	});
	
	// Handle error
	socket.on('error', function(e) {
		console.log("Error caught: " + e.code);
	});
	
	// Handle close event when error or not
	socket.on('close', function(had_error) {
		var message = "Client disconnected";
		message += had_error ? " due to error ": "normally";
		console.log(message);
	});
});


// Manage Server Error
server.on('error', function(e) {

	console.log("Server Error caught : " + e.code);
	
	if(e.code == 'EADDRINUSE') {
	
		console.log("Switching to fallback port in 2 seconds");
		
		setTimeout(function() {
			server.listen(4568, function(){
				console.log("Listening on Port 4568");
			});
		},2000);
	}
});


// Listening
var port = 4567;
server.listen(port, 'localhost');
