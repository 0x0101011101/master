console.log("Creating TCP Server Using the Net Module");

// Loading NET Module
var net = require('net');

// Create TCP Server
var server = net.createServer();

// Create Client Socket
var clientSocket;

// Number of connection
var numConnections = 0;

// Other client has connected to it ?
server.on('connection', function(socket) {  // connection is the Event connection
	
	clientSocket = socket;
	numConnections++;
	
	console.log("TCP Server has receive a connection");
	
	clientSocket.write("Welcome. There are " + numConnections + " active connections\r\n");
	/*
	if (numConnections>=1) {
		console.log("Closing Server. No more new connections allowed");
		server.close(
			function() {
				console.log("Server fully closed");
			}
		); // It's an half close. Existing connection still remain
	}*/
	
	// Listening for 'data' event
	server.on('data', function(data) {
		console.log("Received some data", data.toString());
		if (clientSocket) clientSocket.write("Thanks for saying hi\r\n");
	});
	
	server.getConnections(function(err,count) {
		if(!err) console.log("Concurrent Connections: " + count);
	});
});

// Setting max connection to the server
server.maxConnections = 2;

// Listening
var port = 3456;
server.listen(port, function() {
	console.log("TCP Server Listening on port : " + port);
});