console.log("Connecting to a PostgreSQL Server");

// Loading required module
var pg = require('pg');

// Connection String
var connectionString = "postgres://postgres:password@localhost:5432/myDemoDb";

// Connect to DB
pg.connect(connectionString, function(err,client,done) {
	
	if (err) {
		return console.log("Error getting a client from pool", err);
	}
	
	client.query ("SELECT * FROM foodgroups", function(err,result) {
	
		done(); // release client connection back to the pool
		
		if(err) {
			return console.error("There was an error running the query", err);
		}
		
		console.log(result.rows);
	});
});

// Working w/ a single connection

var client = new pg.Client(connectionString);

client.connect(function(err) {
	
	if (err) {
		return console.log("Error connecting : ", err);
	}
	
	client.query ("INSERT INTO foodgroups VALUES (7, 'test group', 'test description'", function(err,result) {
		
		if(err) {
			return console.error("There was an error inserting the row", err);
		}
		
		console.log(result);
		client.end();
	});
});