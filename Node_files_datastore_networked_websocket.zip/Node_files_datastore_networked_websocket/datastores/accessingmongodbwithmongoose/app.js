console.log("Accessing MongoDB w/ mongoose");

// Loading require module
var mongoose = require('mongoose');

// Connect to MongoDB
mongoose.connect('mongodb://localhost:27017/mydemodb');

var db = mongoose.connection;

// Listener for Error Event
db.on('error', console.error.bind(console,'Connection Error'));

// Listener for Open Event
db.once('open', function() {
	console.log("Connected to Database");
	
	// Set Schema
	var foodSchema = mongoose.Schema({
		name:String,
		servingSize:String
	});
	
	// Define a Model
	var foodModel = mongoose.model('Food', foodSchema);
	
	// Make the query
	foodModel.find({}, function(err,food){
		if(err) return console.error(err);
		console.log(food);
	});
	
	// Adding new Item to Collection 
	var addingItem = new foodModel({
		name:"new food",
		servingSize:"2 medium (30lbs)"
	});
	
	// Save new Item to DB
	addingItem.save(function(err,food){
		if (err) return console.error(err);
		console.log("New food saved");
	});
});
