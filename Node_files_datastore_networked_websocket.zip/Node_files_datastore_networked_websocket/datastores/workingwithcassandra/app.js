// Create Cassandra DB Before
// Launching Cassandra : cqlsh (cmd prompt)
// Create a keyspace named 'mydemokeyspace' and type (cmd prompt) : use mydemokeyspace

console.log("Using Cassandra - Decentralized DB");

var cassandra = require('cassandra-driver');
var _ = require ('underscore');

// Create a Cassandra Client to connect to Cassandra Cluster
var cassandraClient = new cassandra.Client({contactPoints:['localhost'], keyspace:'mydemokeyspace'});

// Declare your Query
var myQuery = "SELECt * FROM food";

// Execute READ Query
cassandraClient.execute(myQuery, function(err, result) {

	// Manage Error
	if (err) {
		console.log(err);
		return;
	}
	else {
		// console.log(result.rows);
		
		_.each(result.rows, function(row) {
			console.log(row.group_id, row.name, row.servingSize);
		});
	}
});

// Execute INSERT Query
var insertQuery = "INSERT INTO food (group_id, name, servingSize) VALUES (?,?, ?)"; // Question mark for protecting from SQL Injection
var params = [7,"testItem","testServingSize"];

cassandraClient.execute(insertQuery, params, {prepare:true}, function(err) {

	// Manage Error
	if (err) {
		console.log(err);
		return;
	}
	else {
		console.log("Data inserted");
	}
});





