console.log("Accessing MongoDB w/ MongoSkin");

// Loading required Module
var mongoSkin = require('mongoskin');
var _ = require ('underscore');

// Create connection
var db = mongoSkin.db("mongodb://localhost:27017/mydemodb",  { useNewUrlParser: true });

// READ Query

db.collection('food').find().toArray(function(err,result) {

	if(err) throw err;
	
	_.each(result, function(doc) {
		console.log(doc._id, doc.name, doc.servingSize);
	});
});

// INSERT Query
db.collection('food').insert({name:'randomItem', servingSize:'2lbs'}, function(err,result) {
	if(err) throw err;
	console.log("Item inserted");
});