// To access to fauxton : http://127.0.0.1:5984/_utils/
console.log("Working w/ CouchDB via nano");

// Loading required module
var nano = require('nano')('http://localhost:5984');
var _ = require('underscore');

// DB Object
var db = nano.use("mydemodb");

// Person Object
var person = {firstName:"Alice", lastName:"Vance"};

/*
// INSERT to DB
db.insert(person, 'testDocument', function(error, http_body, http_headers) {

	if(error) {
		console.log(error.message);
	}
	
	console.log("Document added");
	console.log(http_body);
	console.log(http_headers);

});
*/

/*
// Create permanent View allowing to map view keys to values. when call it, accept document as arguments

var allViewFunction = function(doc) {
	emit(doc._id, doc);
};

// Setting property
var middleWareViewFunction = function(doc) {
	if(doc.hasOwnProperty('middleName')) {
		emit(doc._id, doc);
	}
};
*/


// Using View Function of my db object 
db.view('person', 'has_middleName', function(error, http_body, http_headers) { // 1st : Design document name 2/ View name (try w/ has_middleName)

	if(error) {
		console.log(error);
	}

	console.log(http_headers);
	
	_.each(http_body.rows, function(person) {
		console.log(person.value);
	});
});


// Use http://localhost:5984/mydemodb/_design/person/_view/all to check result