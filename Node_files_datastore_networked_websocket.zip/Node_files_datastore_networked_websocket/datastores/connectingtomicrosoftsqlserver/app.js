console.log("Connecting to a MSSQL Database");

// Loading required module
var sql = require('mssql');

// Configuration Object
var config = {
	user:'mydemouser',
	password:'1234567',
	server:'localhost',
	database:'mydemodb',
	options:{
		instanceName:'DEMOSQLEXPRESS'
	}
};

// Create connection
var connection = new sql.ConnectionPool(config, function(err) {

	// If error
	if (err) throw err;
	
	// Else
	var request = new sql.Request(connection);

	// READ Query
	request.query("select * from fd_groups", function(err,recordset) {
		// If error
		if (err) throw err;
		console.dir(recordset); // Display result of the query
	});
});


// INSERT Query
var ps = new sql.PreparedStatement(connection);

ps.input('name', sql.VarChar(50));
ps.input('description', sql.VarChar(50));

// Execute the Insert
ps.prepare('insert into fd_groups (name, description) values (@name,@description)', function(err) {

	if (err) throw err;
	
	ps.execute({name:'testFoodGroup', description:'testFoodGroupDescription'}, function(err, result) {
		if(err) throw err;
		console.log(result);
	});
});