console.log("Connecting to A Mysql Server");

var mysql = require('mysql');
var _ = require('underscore');

// Create Connection Object
var connection = mysql.createConnection({
	user:'admin',
	password:'admin',
	database:'myDemoDb',
	host:'localhost',
	port:'3306'
});

// Use connection obj to connection
connection.connect(function(err) {
	if (err) {
		throw new Error('Could not connect to db');
	}
});

// QueryString to READ
var queryString = "SELECT * from foodgroups";

connection.query(queryString, function(err,rows,fields) {
	
	if(err) {
		throw new Error('Error performing query');
	}
	
	_.each(row, function(row) {
		console.log(row.id, row.name, row.description); // Table column
	})
});

// QueryString to INSERT
var insertString = "INSERT INTO foodgroups SET ?"; // ? is a placeholder used to replace by insertObject - Fine to protect from SQL Injection
var insertObject = {name:'testFoodGroupName', description:'testFoodGroupDescription'};
var queryString = mysql.format(insertString,insertObject);

var query = connection.query(queryString, function(err,result) {
	
	if(err) {
		throw new Error('Error performing insert');
	}
	
	console.log(result); // Display new SQL Object
});

// To show which query executed
console.log(query.sql);

// End DB connection
connection.end(function(err) {
	console.log("Connection ended");
});









