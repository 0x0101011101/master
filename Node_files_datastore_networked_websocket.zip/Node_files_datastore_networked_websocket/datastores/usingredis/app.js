// To install Node package & run Redis
// $ npm install -g redis-commander
// $ redis-commander

console.log("Implementing Redis");

// Loading required module
var redis = require('redis');

// Create a Client
var redisClient = redis.createClient(6379, "192.168.0.10", {}); // 1st : Port, 2nd : IP, 3rd : Optional Object

// Manage Error
redisClient.on("error", function(err) {
	console.log("Error : " + err);
});

// Manage Ready Event
redisClient.on("ready", function() {
	console.log("Client connected successfully");
});

// To set a Key (here "firstName", 2nd argument is the value)
redisClient.set("firstName", "John", redis.print);

// To retrieve a key
redisClient.get("firstName", function(err,replies) {
	if(err) {
		console.log(err);
	}
	else {
		console.log(replies);
	}
});

// Add Data to the end of a liste
redisClient.rpush("food","fruits");
redisClient.rpush("food","vegetables");
redisClient.rpush("food","meats");
redisClient.rpush("food","dairy");
redisClient.rpush("food","grains");

// Get Data from a listStyleType
redisClient.lrange("food",0,-1, redis.print); // 1st argument : key which reference the list, 2nd : start index, 3rd : end index

// Close the Client Connection
redisClient.quit();



