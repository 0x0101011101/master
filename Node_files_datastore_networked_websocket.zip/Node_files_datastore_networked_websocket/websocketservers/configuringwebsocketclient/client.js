console.log("Configuring Websocket Client");

// Loading Websocket Module
var websocket = require('websocket');

// Create Websocket Client
var webSocketClient = websocket.client;
var wsClient = new webSocketClient();

// Listening on error Event
wsClient.on('connectFailed', function(err) {
	console.log("Could not connect to Server", error.toString());
});

// Listening on connect Event
wsClient.on('connect', function(connection) {
	console.log("Client connected successfully");
	
	// Listen to connection close Event
	connection.on('close', function() {
		console.log("Connection was closed");
	});
	
	// Listen to message Event
	connection.on('message', function(message) {
		
		var messageType = message.type;
		
		if(messageType === "utf8") {
			console.log("Client received UTF8 message : " + message.utf8Data);
		} 
		else if(messageType === "binary") {
			console.log("Client received Binary message - Length : " + message.binaryData.length);
		}
	});
	
	// Simulate some traffic accros from the Client to the Server
	
	function sendingRandomData() {
		
		var data = ['Data1', 'Data2', 'Data3', 'Data4', 'Data5'];
		
		if(connection.connected) {
			var message = data [Math.floor(Math.random() * data.length)];
			connection.sendUTF(message);
			setTimeout(sendingRandomData,5000);
		}
	}
	
	sendingRandomData();
});

// Client connect using the defined sub protocol (demo-protocol)
wsClient.connect("ws://localhost:3456", 'demo-protocol');

