console.log("Working with Websockets Server using WS");

// Loading WS module (WebSocket fastest library)
var ws = require('ws');

// Create a Websocket Server
var webSocketServer = ws.Server;
var wss = new webSocketServer({
	host:'localhost',
	port:4567
});

// Listening connection on Server
wss.on('connection', function(ws) {

	//Listen message event from a Client
	ws.on('message', function(message) {
		
		console.log("Server received message : " + message);
		
		// Send feedback to the Client
		ws.send ("Thanks for the message. " + message, function(err) {
			if (err) {
				console.log("Error sending to Client :" + err);
				return;
			}
			console.log("Server got message and echoed back to the Client");
		});
	});
});