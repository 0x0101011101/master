console.log("Working with WebSockets Client using WS");

// Loading WS module (WebSocket fastest library)
var webSocket = require('ws');

// Create a Websocket Client
var webSocketClient = new webSocket('ws://localhost:4567');

// Listening on Open Event
webSocketClient.on('open', function() { // On event fired when Client & Server has established successfull connection
	
	console.log("Socket Open. Client connected to the Server");
	
	// Send some message from the Client Websocket
	webSocketClient.send("Hi from Client Websocket", function(err) {
	
		if (err) {
			console.log("Error sending to Server : " + err);
			return;
		}
		
		console.log("Client successfully sent message to Server");
	});
	
	// When receiving message from the Server	
	webSocketClient.on("message", function(data,flags) {
	
		console.log("Client received Data from Server : ", data);
		
		// data.binary is set if data is binary
		// otherwise its utf8 encoded
		
		// flags.masked is set if data was masked
		console.log(flags.toString());
	});
});