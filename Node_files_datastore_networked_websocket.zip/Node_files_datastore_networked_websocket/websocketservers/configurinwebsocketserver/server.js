console.log("Configuring Websocket Server");

// Loading http & websocket modules
var http = require('http');
var websocket = require('websocket');

// Create Server
var httpServer = http.createServer(function(req,res) {
	res.writeHead(404);
	res.end();
});

// Server is listening
var port = 3456;
httpServer.listen(port, function(){
	console.log("Server listening on port : " + port);
});

// Create Websocket
var webSocketServer = websocket.server;

wsServer = new webSocketServer({
	httpServer:httpServer,
	autoAcceptConnections:false
});

// Custom function
var isOriginAllowed = function(origin) {
	return true;
};

// Websocket listening
wsServer.on('request', function(request) {
	// allow this request or not ?
	if(!isOriginAllowed(request.origin)) {
		request.reject;
		console.log("Request was rejected based on origin");
		return;
	}
	
	var connection = request.accept("",request.origin); //1st arg is protocol/subprotocol for the connection
	console.log("Request accepted");
	
	// When data received
	connection.on('message', function(message) {
	
		var messageType = message.type;
		
		if (messageType === "utf8") {
			console.log("UTF8 message received " + message.utf8Data);
			connection.sendUTF("Got the UTF8 message. Thanks");
		}
		else if (messageType === "binary"){
			console.log("Binary message received - Length : " + message.binaryData.length);
			connection.sendUTF("Got the Binary message. Thanks Sending it back");
			connection.sendBytes(message.binaryData);
		}
	});
	
	// When closing connection
	connection.on('close', function(reasonCode, description) {
		console.log("Connection was disconnected");
		console.log(reasonCode, description);
	});
});
