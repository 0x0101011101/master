console.log("Using socket.io");

// Loading http & fs Module
var http = require('http');
var fs = require('fs');

var index = fs.readFileSync(__dirname + '/index.html');

// Creating Web Server
var server = http.createServer(function(req,res) {
	res.writeHead(200, {'Content-Type':'text/html'});
	res.end(index); // Return HTML File
});

// Creating Websocket IO & attach it to the server created before
var io = require('socket.io-client')(server);

// Listening connection on IO Websocket
io.on('connection', function(socket) {
	console.log("Connection detected");
	
	// Emit to all connected sockets that a new user has connected
	io.emit("newConnection", {id:socket.id});
	
	// Listening on disconnect Event
	socket.on('disconnect', function() {
		console.log('Client disconnected');
		io.emit("clientDisconnected", {id:socket.id});
	});
	
	// Listen to chat Event coming from the Client
	socket.on('chat', function() {
		
		var message = data.message;
		
		// Listen for chat event and send it back to all connected sockets
		io.emit("chat", data);
	});
});

// Server listening
var port=3456;
server.listen(port, function() {
	console.log("Server listening on port : " + port);
});