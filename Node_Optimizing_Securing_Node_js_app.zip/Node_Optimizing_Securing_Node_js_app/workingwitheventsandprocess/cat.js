var events = require('events');

// Emitter constructor
var Emitter = events.EventEmitter;

// Create Event Emitter
var cat = new Emitter();

// Define Events
cat.meow = function() {
	cat.emit("meow","I am meowing now"); // name of custom event, message
};

cat.sleep = function(duration) {
	
	cat.emit("sleep","I am sleeping now");
	
	setTimeout(function() {
		cat.emit('awake', "I am awake now");
	}, duration);
}

// Export the cat !
module.exports = cat;