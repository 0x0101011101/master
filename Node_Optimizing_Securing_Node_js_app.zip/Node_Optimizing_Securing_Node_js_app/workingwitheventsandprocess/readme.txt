Event emitter object to create object
spawn command to create separate & distinct child process
Exec allow to run system command in node app as child process
Fork method create a separate instance of the V8 engine (generate a child process running in another node instance)
Cluster to create master/slave process
setTimeout & setInterval (not use on critical or embed app)