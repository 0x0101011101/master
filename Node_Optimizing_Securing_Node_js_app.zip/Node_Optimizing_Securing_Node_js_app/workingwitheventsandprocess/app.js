var cat = require('./cat');

cat.on('meow', function() {
	console.log("The cat just meowed");
})

cat.on('sleep', function(data) {
	console.log("The cat is just sleeping now");
	console.log("Data from the cat : " + data);
})

cat.on('awake', function() {
	console.log("The cat is awaken");
})

// Cat behaviour
cat.meow();
cat.sleep(5000);

