console.log("Hashing data");

var crypto = require('crypto'); // Core module

// Create Hash Object based on the Algorithm SHA1
var myHashObject = crypto.createHash('sha1');

// Data to be hashed
var data = "JustASimpleString";

// Update myHashObject w/ data
myHashObject.update(data,'utf8');

// Calculate the digest based on that data
// NB : After digest, i can't myHashObject anymore 
var digest = myHashObject.digest('hex');

console.log("Result of hashing the data" + data);
console.log("Burp : " + digest);



