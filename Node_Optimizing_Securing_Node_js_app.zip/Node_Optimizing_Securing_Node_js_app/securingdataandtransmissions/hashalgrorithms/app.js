console.log("Node hash algorithms");

var crypto = require('crypto'); // Core module

// Display crypto algorithms
console.log (crypto.getHashes());