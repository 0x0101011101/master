console.log("Encrypting Data w/ OpenSSL Ciphers");
console.log("\n");

var crypto = require('crypto');
var password = new Buffer("myPassword"); // password known by the parties
var message = "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."; // The message to encrypt & decrypt

// To display Ciphers available
//console.log(crypto.getCiphers());


// ENCRYPTING
// Create Cipher Object using "AES256"
var myCipher = crypto.createCipher("aes256", password);

// Update my Cipher Object w/ message
var myEncrypted = myCipher.update(message,'utf8','hex'); // message, inputEncoding, outputEncoding

// Get my encrypted value using myCipher Object
myEncrypted += myCipher.final('hex');

// Display encrypted value
console.log("Encrypted value : " + myEncrypted);
console.log("\n");


// DECRYPTING
// Create Cipher Object using "AES256"
var myDecipher = crypto.createDecipher("aes256", password);

// Update my Cipher Object w/ message
var myDecrypted = myDecipher.update(myEncrypted,'hex','utf-8'); // myEncrypted, inputEncoding, outputEncoding

// Get my encrypted value using myCipher Object
myDecrypted += myDecipher.final();

// Display encrypted value
console.log("Decrypted value : " + myDecrypted);
console.log("\n");