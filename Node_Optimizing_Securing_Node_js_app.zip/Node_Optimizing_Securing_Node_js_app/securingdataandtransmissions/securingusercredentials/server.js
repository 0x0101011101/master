console.log("Securing User Credentials");

// Loading necessary module
var express = require('express');
var bodyParser = require('body-parser');
var mongoose = require('mongoose');
var bcryptjs = require('bcryptjs');

// Mongoose settings
mongoose.connect("mongodb://localhost/mydemodb");
var db = mongoose.connection;

db.on("error", function(err) {
	console.log(err);
});

db.once("open", function() {
	console.log("Connected to DB");
});

// Declare User Schema 
var userSchema = mongoose.Schema({
	
	firstName: 'string',
	lastName: 'string',
	userName: 'string',
	password:'string'
});

// Declare User Model
var User = mongoose.model("User", userSchema);

// Create App & Setting include bodyParser settings
var app = express();
app.use(express.static(__dirname + '/public')); // To view the /public folder
app.use(bodyParser.urlencoded({
	extended:true
}));
app.use(bodyParser.json());

// Posting Form
app.post("/newAccount", function(req,res) {

	// get Credentials coming in FROM Form
	var firstName = req.body.firstName;
	var lastName = req.body.lastName;
	var userName = req.body.userName;
	var password = req.body.password;
	
	// Using bcriptjs
	
	// Generate a salt (random number)
	bcryptjs.genSalt(10, function(err,salt) { // 10 number of round to generate the salt
		
		if(err) {
			console.log(err);
			return;
		}
		
		// If no error, calculate Hash
		bcryptjs.hash(password, salt, function(err, hash) {
		
			// Create a new User w/ hashed password
			var user = new User({
				firstName:firstName,
				lastName:lastName,
				userName:userName,
				password:hash
			});
		
			// Save New User to the User Collection in MongoDB
			user.save(function(err,user) {
				
				if(err) {
					console.log("Error Saving User");
					res.end("Can not create User");
				}
				
				res.end("User successfully created");
				console.log("User created");
			})
		});
	});
});

// Listen to chosen port
port = 3456;
app.listen(port, function() {
	console.log("Server listening on port : " + port);
});


// Use compare method of bcryptjs to compare hash value stored in db