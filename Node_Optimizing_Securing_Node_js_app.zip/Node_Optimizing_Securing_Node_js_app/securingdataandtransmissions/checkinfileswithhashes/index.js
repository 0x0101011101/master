console.log("Checking Files w/ Hashes");

// Loading FS to readstream Files
var fs = require('fs');

// Loading crypto for hash object creation
var crypto = require('crypto');


var shaSumFromNodeWebSite = "dbe467e3dabb6854fcb0cd96e04082268cb1e313ce97a4b7100b2ed152b0a0ab";

// Create Hash Object based on SHA256
var calcShaSum = crypto.createHash('SHA256');

// Reading the file downloaded
var stream = fs.ReadStream('node-v10.15.0.tar.gz');

// Listen data event cause the stream flowing file data into my handler function
stream.on('data', function(chunk) {

	// Update calcShaSum w/ chunk
	calcShaSum.update(chunk);
});

// Listen to the end of my stream, so calculate the Digest
stream.on('end', function() {
	console.log("Calculating Digest ...");
	var digest = calcShaSum.digest('hex');
	
	console.log("Calculated ShaSum : " + digest);
	console.log("Provided ShaSum : " + shaSumFromNodeWebSite);
	
	if (digest == shaSumFromNodeWebSite) {
	
		console.log("File integrity is OK");
	
	} else {
		console.log("Warning : File is corrupted");
	}
});
