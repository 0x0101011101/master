console.log("Create Credential Objects");

var fs = require("fs");
var crypto = require("crypto");

// To generate PrivateKey using OpenSSL : openssl genrsa -out myPrivateKeym.pem 1024
// To generate a Certificate Signing Request (CSR) : openssl req -new -key myPrivateKey.pem -out myDemoCSR.pem
// To receive trustly Public Key OR Self-Sign : openssl x509 -req -in myDemoCSR.pem -signkey myPrivateKey.pem -out myCert.pem

var privateKey = fs.readFileSync("myPrivateKey.pem");
var cert = fs.readFileSync("myCert.pem");

// Create an object of my Public & Private Keys
var myPrivateAndPublicKeys = {
	key:privateKey,
	cert:cert
}

// Creating the Credential Object
var myCredentialsObject = crypto.createCredentials(myPrivateAndPublicKeys);

console.log("My Credentials Object" + myCredentialsObject);

