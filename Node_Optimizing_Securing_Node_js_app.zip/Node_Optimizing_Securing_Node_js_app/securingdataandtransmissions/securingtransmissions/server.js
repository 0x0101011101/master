console.log("TLS Server"); // Transport Layer Security for encrypted data communication between itself and a client

// Loading necessary module
var tls = require('tls');
var fs = require('fs');

// Create Server & Client Certificate w/ OpenSSL
// openssl genrsa -out myClientPrivateKey.pem 1024
// openssl req -new -key myClientPrivateKey.pem -out myClientCSR.pem
// openssl x509 -req -in myClientCSR.pem -signkey myClientPrivateKey.pem -out myClientCert.pem

// TLS Server settings
var options = {
	key: fs.readFileSync('myServerPrivateKey.pem'),
	cert: fs.readFileSync('myServerCert.pem'),
	requestCert: true, // require a certificate from any connecting client
	ca: [fs.readFileSync('myClientCert.pem')], // Indicate here trusted cert
	rejectUnauthorized:false // default value
}

// TLS Server create
var tlsServer = tls.createServer(options, function(cts) { // cts : Clear Text Stream
	console.log("Server : connection");
	console.log("Server connected", cts.authorized ? 'authorized' : 'unauthorized'); // base on ca Trusted Cert
});

// TLS Server listening
var port = 5678;
tlsServer.listen(port, function() {
	console.log("TLS Server listening on Port : " + port); 
});

// TO TEST
// node server.js
// w/ Open SSL : 


