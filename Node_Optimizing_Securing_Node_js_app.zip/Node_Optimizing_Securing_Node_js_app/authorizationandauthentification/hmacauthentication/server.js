console.log("Session Based Authentication");

// Loading require modules
var express = require('express');
var app = express();

// MongoDB Settings & Start
require("./config/mongoose")("mongodb://localhost/mydemodb");

// Express Settings 
require("./config/express")(app);

// Passport module loading
require("./config/passport")();

// Insecured Routes module loading
require("./config/routes/routes")(app);

// Secured Routes module loading
require("./config/routes/secureRoutes")(app);


// Server Listening
var port = 3456;
app.listen(port, function() {
	console.log("Server listening on port : " + port);
});