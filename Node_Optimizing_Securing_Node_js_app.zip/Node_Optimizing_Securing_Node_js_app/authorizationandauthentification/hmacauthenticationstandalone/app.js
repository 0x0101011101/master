console.log("Generating a HMAC"); // Hashed Message Authentication Code Object
var crypto = require('crypto');

var secretKey = "mySecretKey";
var message = "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum";

var myHmac = crypto.createHmac("SHA1", secretKey);

myHmac.update(message);
console.log(myHmac.digest('hex'));

// Anciennce version
//myHmac.digest('hex'); // Output encoding

/*
myHmac.end(message,'utf-8', function() {
	var code = myHmac.read();
	console.log(code);
})
*/

