var mongoose = require('mongoose');

var userSchema = mongoose.Schema({

	firstName:'string',
	lastName:'string',
	userName:'string',
	password:'string'
});

module.exports = mongoose.model('User',userSchema);

