var express = require('express');

var role_admin = function(req,res,next) {
	
	var roles = req.user.roles;
	
	if(roles.indexOf('admin') >= 0) {
		console.log("User authorized as Admin");
		return next();
	}
	
	console.log("User not authorized as Admin");
	res.redirect('/users/home');
}

var checkAuthentication = function(req,res,next) {
	if(req.isAuthenticated())
		return next();
	res.redirect('/login');
}

module.exports = function(app) {

	var secureRouter = express.Router();
	
	// All routes only rendered if a user is authenticated using checkAuth middleware
	secureRouter.use(checkAuthentication);
	
	secureRouter.get('/home', function(req,res) {
		res.render('home');
	});

	// only rendered if user is authenticated and authorized w/ role admin
	secureRouter.get('/admin', role_admin, function(req,res) {
		res.render('admin');
	})
	
	app.use("/users", secureRouter);
}