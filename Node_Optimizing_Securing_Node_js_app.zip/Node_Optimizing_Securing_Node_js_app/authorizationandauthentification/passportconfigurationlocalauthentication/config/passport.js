var passport = require('passport');
var LocalStrategy = require('passport-local').Strategy; // LocalStrategy constructor to build passport strategy
var User = require('./userModel'); // User model used to interact w/ DB
var bcrypt = require('bcryptjs'); // password encryption

var checkValidPassword = function (user,password) {
	return bcrypt.compareSync(password, user.password); // compare password from the login form and the one stored in user from DB
}

module.exports = function() {

	// Setting a passport to work w/ my LocalStrategy
	passport.use('login', new LocalStrategy(
		
		function(username,password, done) { // To implement custom functionnality to authenticate a user
		
			User.findOne( // Using User Model
			{
				userName:username
			},
			
			function(err,user) {
				if(err) return done(err);
				
				// Verify User
				if(!user) {
					console.log("User not found");
					return done(null, false, {message: "User not found"}); // message is going to be flashed
				}
				
				// Verify password
				if(!checkValidPassword(user,password)) {
					console.log("Password invalid");
					return done(null,false, {message: "User Password incorrect"}); // message is going to be flashed
				}
				
				console.log("Authentication passed");
				return done(null, user);// Return the User
				
			});
		}
	));
	
	// Serialize user instance from session store data (not need to pass user credentials on every request)
	passport.serializeUser(function(user,done) {
		done(null, user._id);
	});
	
	// Deserialize user instance from session store data
	passport.deserializeUser(function(id,done) {
		User.findById(id, function(err,user) {
			done(err,user);
		})
	});
}