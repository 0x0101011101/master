var express = require('express');
var expressSession = require('express-session'); // Help us work w/ sessions in express apps
var bodyParser = require('body-parser');
var cookieParser = require('cookie-parser');
var logger = require('morgan');
var flash = require('connect-flash');
var passport = require('passport');

module.exports = function(app) {
	
	// Setting Template Engine
	app.set('views', __dirname + "../../views");
	app.set('view engine', 'jade');
	
	// Setting Logger
	app.use(logger('dev'));
	
	// Setting CookieParser
	app.use(cookieParser());
	
	// Setting bodyParser Form Data & Json
	app.use(bodyParser.urlencoded({
			extended:"true"
	}));
	app.use(bodyParser.json());
	
	// Setting ExpressSession
	app.use(expressSession({
		secret:'myDemoKey',
		//resave:true,
		//saveUninitialized:true
	}));
	
	// Setting Flash to flash message to my request
	app.use(flash());
	
	// Setting Passport Template
	app.use(passport.initialize());
	app.use(passport.session());
}