// Defining some routes that passport can user for authentication by calling our Local Strategy
var passport = require('passport');
var express = require('express');

var checkAuthentication = function(req,res,next) {
	if(req.isAuthenticated())
		return next(); // Allow the homepage to be rendered out
	
	// If not authenticated, return to Login Page
	res.redirect('/login');
}

module.exports = function(app) {
	
	var router = express.Router();
	
	router.get('/', function(req,res) {
		res.render('login'); // Using Jade
	});
	
	router.get('/login', function(req,res) {
		
		var message = req.flash('error')[0]; // first index of array
		
		console.log(message);
		
		if(message) {
			res.render('login', {message:message}); // message from passport.js if authentication is failing
		}
		else {
			res.render('login');
		}
	});
	
	router.get('/logout', function(req,res) {
		req.logout();
		res.redirect('/login');
	});
	
	router.get('/home', checkAuthentication, function(req,res) { // Access to Home Page if the User is authenticated
		res.render('home');
	});
	
	router.post('/login',passport.authenticate('login', { // delegating the callback for this to passport using the name of my LocalStrategy (login)
		successRedirect: '/home',
		failureRedirect: '/login',
		failureFlash: true // To display flash message
	}));
	
	// The app user our router
	app.use("/",router);
}


