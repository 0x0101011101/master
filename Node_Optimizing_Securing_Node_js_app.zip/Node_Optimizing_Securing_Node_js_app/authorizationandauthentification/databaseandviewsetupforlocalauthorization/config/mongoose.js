var mongoose = require('mongoose');

module.exports = function(connectionString) {

	mongoose.connect("mongodb://localhost/mydemodb", { useNewUrlParser: true });
	//mongoose.connect(connectionString);
	
	var db = mongoose.connection;
	db.on("error", function(err) {
		console.log("Error : " + err);
	});
	db.once("open", function() {
		console.log("Connected to DB");
	});
}