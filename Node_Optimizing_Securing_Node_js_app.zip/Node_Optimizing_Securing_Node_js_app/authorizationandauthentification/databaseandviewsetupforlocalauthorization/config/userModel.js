var mongoose = require('mongoose');

var userSchema = mongoose.Schema({

	firstName:'string',
	lastName:'string',
	userName:'string',
	password:'string',
	roles:['string']
});

module.exports = mongoose.model("User",userSchema);
