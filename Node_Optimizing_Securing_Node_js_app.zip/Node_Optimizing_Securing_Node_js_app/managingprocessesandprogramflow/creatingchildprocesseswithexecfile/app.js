console.log('Creating Child Processes W/ ExecFile');

var execFile = require("child_process").execFile;

// Creating the Child Process#1

var childProcess1 = execFile("node", ["helloApp.js"], function(error,stdout, stderr) { // stdOut/stdErr will be buffered - Be carefull of buffer overflow

	if (error) console.log("Error : " + error);
	
	console.log("StdOut : " + stdout);
	console.log("StdErr : " + stderr);
});

// Instead of executing in a subshell
// exec("node helloApp.js", function(....))