console.log("A random App");

// Runs for 4 seconds outputting stuff to the console stdOut and then Exits

var hello = ["Hello","Hola","Bonjour"];

//
setInterval(function() {
	var message = hello.pop();
	console.log(message);
}, 1000);

// 
setTimeout(function() {
	console.log("Goodbye");
	process.exit();
},4000);