console.log("Using Node Timers");

// Execute a ONE TIME callback function after a certain amount of time

var name = "Buzonie";

var oneTime = setTimeout(function() {

	console.log("Hi " + name + " from inside the callback of setTimeout");

}, 2000, name);

// To cancel this Timeout
/*
clearTimeout(oneTime);
console.log("setTimeout was cancelled");
*/


// Execute a callback repeatedly after a certain amount of time

var count = 0;

var multipleTimes = setInterval(function() {

	count++;
	console.log("Running setInterval timeOut : " + count);
	
	if (count >=5) {
		console.log("Cancelling setInterval");
		clearInterval(multipleTimes);
	}
},1000, count);