console.log("Creating Child Processes With Exec");

// Loading child_process module for exec system command
var exec = require('child_process').exec;

// Command var will be used to create the Child Processes
var command = "node sampleNodeApp.js";

// Child Process Object #1
var childProcess1 = exec(command, function(error,stdout,stderr) {

	if (error) console.log ("error : " + error.code);
	
	console.log("StdOut : " + stdout);
	
	console.log("StdErr : " + stderr);

});



