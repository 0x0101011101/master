// Parent process
console.log("Creating Child Processes w/ Fork");
console.log("Parent PID is : " + process.pid); // Parent process

// Loading Fork property
var fork = require('child_process').fork;
var command = __dirname + "/server.js";

// Creating Child process using Fork
var childProcess = fork(command);

// Sending data to the Child Processes
// Using setTimeout to allow the child process to be launched
setTimeout(function() {
	console.log("Parent : Sending a message to child process");
	childProcess.send({'message':"statusCheck"});
}, 2000);

// Listen to Child Process answer
childProcess.on('message', function(m) {
	console.log("Parent: Got a message back from Child Process : " + m.message);
});

// Listen when my Child Process exit
childProcess.on('exit', function() {
	console.log("Parent : Child process ended");
});

setTimeout(function() {
	console.log("Artificially forcing my Parent Process to run");
}, 999999999);



