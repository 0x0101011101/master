// Child Process
var http = require('http');

var server = http.createServer(function(req,res) {
	res.end("Hi, i am a simple http server");
});

var port = 3456;
server.listen(port, function(){
	console.log("Child: Server is listening on port : " + port);
	console.log("Child PID is " + process.pid);
});

// Listen message from Parent process
process.on('message', function(m) {
	if (m.message == 'statusCheck') {
		process.send({'message':'Doing well, server is up and running'});
	}
});