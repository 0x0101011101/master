// Using Cluster Module in case Node run on multi-core system
console.log("Clustering Processes");

var cluster = require('cluster');
var http = require('http');
var os = require('os');

// Determine how many cpu 
var numCPU = os.cpus().length
console.log("Number of CPU's on machine : " + numCPU);

// Create a Child/Slave process to help w/ HTTP server for each CPU
// Sharing among number of CPU available

// Create the cluster (1 master, many slave)
// Is this particular running process is the master

if (cluster.isMaster) { //Is it the master process
	// Create slave Process for each CPU
	for (var i=0; i<numCPU; i++) {
		cluster.fork();
	}
	
	// Listening exit Event if any those slave process end
	cluster.on('exit', function(worker, code, signal) {
		console.log("The worker w/ id : " + worker.id + " has ended");
		console.log("Code : " + code);
		console.log("Signal : " + signal);
	});
}
else { // It's a slave/worker process

	var server = http.createServer(function(req,res) {
		res.end("Hi from ou simple http server");
	});
	
	// All slave processes listen to port : 3456
	server.listen(3456, function() {
		console.log("Slave http server online");
	});
}
