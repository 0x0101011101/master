console.log("Creating Child Processes With Spawn");

// Loading child_process module for spawning
var spawn = require('child_process').spawn;


// Child Process Object #1
var childProcess1 = spawn("node", ['sampleNodeApp.js']); // Arg : the command to run, app name

// Listener from parent app to get back data from the running childProcess1 w/ listening on the stdout & stderror 

// Listening on stdOut Event
childProcess1.stdout.on('data', function(data) {
	console.log("Output from Child Process #1 - StdOut:\n" + data);
});

// Listening on stdError Event
childProcess1.stderr.on('data', function(data) {
	console.log("Error : " + data);
});

// Listening on Close Event
childProcess1.on('close', function(code) {
	console.log("Child Process#1 ended. Exit code: " + code);
});