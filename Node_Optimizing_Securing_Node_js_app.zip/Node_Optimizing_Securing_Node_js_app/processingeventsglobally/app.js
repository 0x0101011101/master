// Using process object to cache & respond to certain events - Its also an instance of Event Emitter
console.log("Processing Events Globally");

// Exit Event
process.on('exit', function() {
	console.log("App is about to exit");
	console.log("Take this time to do any clean up or management that is necessary");
});


// uncaughtException Event
process.on('uncaughtException', function() {
	console.log("Caught an Exception");
	console.log("Potentially take this time to save unsaved data");
});

/*
// Simulate app exiting
setTimeout(function() {
	console.log("Time to kill the App");
	process.exit();
},4000);
*/

// Simulate app crashing
setTimeout(function() {
	console.log("Hi from the Timeout function");
	process.exit();
},5000);

throw new Error("Simulating an error");

