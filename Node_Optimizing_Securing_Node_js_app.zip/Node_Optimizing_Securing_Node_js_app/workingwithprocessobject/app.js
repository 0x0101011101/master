console.log("Working w/ The Process Object");

console.log("Current working directory : " + process.cwd());

process.env.MY_CURRENT_ENV = "development";
process.env.MY_CURRENT_ENV = "production";

if (process.env.MY_CURRENT_ENV == "development") {
	myServerPort = 1111;
}
else if (process.env.MY_CURRENT_ENV == "production") {
	myServerPort = 2222;
}

// STDOUT
//process.stdout.write("This is what console.log does\n");

// STDIN
var dataFromStdIn = "";

/*
process.stdin.on('data', function(chunk) {	
	dataFromStdIn += chunk;	
});

process.stdin.on('end', function() {	
	console.log("Data from stdin:\n " + dataFromStdIn);
});
*/

// argv property to access line command arguments - it's a an array // Launch // node.app.js username/role
var argv = process.argv;
console.log(argv);

var username = argv[2];
var userRole = argv[3];
console.log("Username : " + username);
console.log("Role : " + userRole);
