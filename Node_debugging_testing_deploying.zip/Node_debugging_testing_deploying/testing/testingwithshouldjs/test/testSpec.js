// Loading required module
var should = require('should');
var calc = require('../lib/calc');

// Setting a describe block
describe("Complete calculator", function() {
	
	// Define Test#1
	it("Should provide add, sub, mult, divide functionnality", function() {
		// Setting up assertion w/ Should library
		calc.should.have.keys('add','substract','multiply');
	});
	
	// Define Test#2
	it("Should have div property", function() {
		// Setting up assertion w/ Should library
		calc.should.have.property('divide');
	});
});

// To test : mocha test/testSpec.js