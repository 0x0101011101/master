// Loading required module
var app = require('../server.js');
var request = require('supertest');

// Create Mocha Block
describe("GET /fruitInfo", function(done) {
	
	it('respond with json and 200 status', function(done) {
		
		// Define Client Request
		request(app)
		.get('/fruitInfo')
		.set('Accept','application/json')
		// Assertion
		.expect(200) // Response - User other value(400 for instance) to generate failed test
		.expect('Content-type', /json/) // Header response of type json (regular expression)
		// Perfom the request
		.end(function(err,res) {
			if(err) return done(err);
			done(); // Test is complete
		});
	});
});

// To launch : mocha test/testSpec.js