console.log("Testing with SuperTest");

// Loading required module
var express = require('express');

// Declare some data
var data = {
	'fruit':'A fruit is bla',
	'vegetable':'A vegetable is'
};

// Create App
var app = express();

// Routes
app.get('/fruitInfo', function(req,res) {
	
	var info = data['fruit'];
	res.status(200).send({name:'fruit', info:info});

});

// Server listening
var port = 3456;
app.listen(port, function() {
	console.log("Server listening on port : " + port);
});

// To use this app in a test
module.exports = app;