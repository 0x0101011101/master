console.log("Testing with Nodeunit");

var calc = require('./calc');

exports.testAdd = function(test) {
	
	test.expect(2); // 2 is the number of assertion (number of test.equal below ...)
	
	// 1st test w/ add
	test.equal(calc.add(2,2),4,"Calculator adds two number correctly (2 and 2 = 4)"); // 2nd argument : expected result
	
	// 2nd test to generate an error
	test.throws(function(){calc.add(2,"string")}, Error); // Throw Esception if theres an error
	
	test.done();
}

exports.testSubstract = function(test) {
	
	test.expect(1);
	
	// 1st test w/ substract
	test.equal(calc.substract(2,2),0,"Calculator substract two number correctly (2 - 2 = 0)"); // 2nd argument : expected result
		
	test.done();	
}