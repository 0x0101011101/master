// To install Nodeunit : npm install -g nodeunit

console.log("Unit Testing with NodeUnit module");

module.exports = {

	add: function(val1,val2) {
		checkArguments(val1,val2);
		return val1 + val2;
	},
	substract: function(val1,val2) {
		checkArguments(val1,val2);
		return val1 - val2;
	},
	multiply: function(val1,val2) {
		checkArguments(val1,val2);
		return val1 * val2;
	},
	divide: function(val1,val2) {
		checkArguments(val1,val2);
		return val1 / val2;
	}
	
};

function checkArguments(val1,val2) {

	if(isNaN(val1)) {
		throw new Error("Arg#1 invalid");
	}
	
	if(isNaN(val2)) {
		throw new Error("Arg#2 invalid");
	}
}