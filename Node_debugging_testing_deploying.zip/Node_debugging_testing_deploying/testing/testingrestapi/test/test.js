console.log("Testing Rest API");

// Loading required module
var expect = require('chai').expect;
var superagent = require('superagent');

// Create Mocha Block
describe('my rest api server', function() {
	
	var id;
	
	// Test#1
	it('create a food item', function(done) {
	
		superagent.post('http://localhost:3456/api/foods')
			.send({name:'demofoodItem', servingSize:'3lbs'})
			.set('Accept','application/json')
			.end(function(err,res) {
				// Make Assertion
				expect(err).to.be.null;
				expect(res.body).to.have.property('message','food Item added');
				
				var food = res.body['food'];
				expect(food).to.contain.keys('_id','name','servingSize');
				
				id = food['_id'];
				expect(id).not.to.be.null;
				
				done(); // Test finish
			});
	});
	
	// Test#2
	it('retrieve all food Item', function(done) {
	
		superagent.get('http://localhost:3456/api/foods')
			.set('Accept','application/json')
			.end(function(err,res) {
				
				// Make Assertion
				expect(err).to.be.null;
				
				expect(res.body).to.be.instanceOf(Array);
				
				expect(res.body.length).to.be.at.least(1);
				
				done(); // Test finish
			});
	});
	
	// Test#3
	it('retrieve a food Item', function(done) {
	
		superagent.get('http://localhost:3456/api/foods/' + id)
			.set('Accept','application/json')
			.end(function(err,res) {
				
				// Make Assertion
				expect(err).to.be.null;
				
				expect(res.body).to.be.instanceOf(Object);
				
				expect(res.body).to.contain.keys('_id','name','servingSize');
				
				done(); // Test finish
			});
	});
	
	// Test#4
	it('update a food item', function(done) {
	
		superagent.put('http://localhost:3456/api/foods' + id)
			.send({name:'demofoodItem', servingSize:'5lbs'})
			.set('Accept','application/json')
			.end(function(err,res) {
				// Make Assertion
				expect(err).to.be.null;
				expect(res.body).to.have.property('message','food Item updated');

				done(); // Test finish
			});
	});
	
	// Test#5
	it('delete a food item', function(done) {
	
		superagent.del('http://localhost:3456/api/foods' + id)
			.set('x-api-key','123456')
			.set('Accept','application/json')
			.end(function(res) {
				// Make Assertion
				expect(res.body).to.have.property('message','food Item deleted');

				done(); // Test finish
			});
	});
});


