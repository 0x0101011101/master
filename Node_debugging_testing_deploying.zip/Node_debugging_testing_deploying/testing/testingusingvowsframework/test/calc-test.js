console.log("Using The Vows Testing Framework");

// Loading required module
var vows = require('vows');
var assert = require('assert');
var calc = require('../lib/calc.js');

// Define a test Suite
var mySuite = vows.describe('calc-test'); // name of the test Suite is the same as the present .js file

// Adding batches to the test Suite (you can add many Batch you want)
mySuite.addBatch({
	
	// Add contexts (properties of batch object - nb : theses context are executed in parallel	
	'simple context': {
		// Define Test : topics (sync or async funcà & vows (receive a topic and perform assertion on that topic)
		topic:12, // topic can be a value or a function
		'should be equal to 12':function(topic) {
			assert.equal(topic,12)
		}
	},
	'when adding two values synchronously': {
		topic:function() {
			return calc.add(1,2);
		},
		'one plus two should equal three':function(topic){
			assert.equal(topic,3);
		}
	},
	'when adding two values asynchronously': {
		topic: function() {
			calc.addAsync(3,5,this.callback); // when finish, pass the callback to our vows
		},
		'three and five should return 8': function(err,value) {
			//test that value is a number
			assert.isNumber(value);
			
			//check that value is what we expect 8
			assert.equal(value,9);
			
			//check that error is null
			assert.isNull(err);	
		}
	}
}).run();