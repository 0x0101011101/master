//Loading required module
var assert = require('assert');
var calc = require('../lib/calc');

// Create block
describe("Calculator", function(){
	
	// Make Test#1 Synchronous 
	it("Should multiply 2 * 2 and get 4", function() {
		
		// Passing the assertion
		assert.equal(calc.multiply(2,2),4);
	});
	
	// Make Test#2 Synchronous
	it("Should divide 9 / 3 and get 3", function() {
		
		// Passing the assertion
		assert.equal(calc.divide(9,3),3);
	});
	
	// Make Test#3 Asynchronous
	it("Should add 3 + 4 and get 7", function(done) {
		
		calc.addAsync(3,4, function(err,result) {
			
			// Include assertion
			assert.equal(result,10);
			
			done();
		});
	});
});

// type mocha to launch test
