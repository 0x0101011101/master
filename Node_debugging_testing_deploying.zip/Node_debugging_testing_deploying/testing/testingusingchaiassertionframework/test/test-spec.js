// Loading required module
var calc = require('../lib/calc');
var chai = require('chai');

// Several interface to make different assertion
var should = chai.should();
var expect = chai.expect;
var assert = chai.assert;

// Create Mocha Block
describe("Calculator", function() {
	
	// 1st Test
	it("Should multiply 4 and 3 and get 12", function() {
		// Use Assert type syntax
		assert.equal(calc.multiply(4,3), 12);
	});
	
	//2nd Test
	it("Should divide 48 by 4 and get 12", function() {
		// Use Expect type syntax
		expect(calc.divide(48,4)).to.equal(12);
	});
	
	//3rd Test
	it("Should substract 3 from 15 and get 12", function() {
		// Use Should type syntax
		calc.substract(15,3)).should.be.equal(12);
	});
});

// To test : mocha test/test-spec.js