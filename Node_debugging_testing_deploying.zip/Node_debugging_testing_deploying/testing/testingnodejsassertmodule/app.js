console.log("Testing with The Assert Module");

var assert = require('assert');

function userCredentialsValid(username, password) {

	var users = {
		"andy":"nodedemo",
		"keysha":"1234567",
		"joanne":"password"
	}
	
	if(!username || !password) {
		throw new Error("Incomplete Credentials");
	}
	
	if(users[username]) {
		
		if(password == users[username]) {
			console.log("valid credentials provided");
			return true;
		}
		
		console.log("Invalid password provided : " + password);
		return false;
	}
	
	console.warn("Invalid username provided : " + username);
	return false;

};

// User assert function
// assert(false,'myMessage'); // 1st argument : condition to test
// assert(userCredentialsValid("andy","nodedemoX"),"credentials invalid");
// assert.ok(condition, [message]);
assert.equal(userCredentialsValid("joanne","wrongPassword"), true, 'are credentials valid'); // 1st argument : returned value, 2nd argument : expected value
