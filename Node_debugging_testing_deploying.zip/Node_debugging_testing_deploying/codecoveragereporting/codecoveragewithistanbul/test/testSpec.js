// Loading required module
var calc = require('../lib/calc');
var assert = require('assert');

// Dummy assertion
//assert.equal(true, true);

// Simple assertion
// assert.equal(calc.add(1,1),2);

// Multiple assertion to test the if condition in calc.js
assert.equal(calc.add(1,1),2);
assert.equal(calc.add("notANumber",1), "Invalid Arguments");
assert.equal(calc.add(2,"notANumber"), "Invalid Arguments");
assert.equal(calc.add("notANumber","notANumber"), "Invalid Arguments");

// To test : istanbul cover test/testSpec.js