// Loading required Module
var calc = require('../lib/calc');
var assert = require('assert');

// Multiple assertion to test the if condition in calc.js
assert.equal(calc.add(1,1),2);
assert.equal(calc.add("notANumber",1), "Invalid Arguments");
assert.equal(calc.add(2,"notANumber"), "Invalid Arguments");
assert.equal(calc.add("notANumber","notANumber"), "Invalid Arguments");

// To test : cover run test/testSpec.js
// un directory .coverage_data est créé
// Type cover report html > un directory cover_html est créé