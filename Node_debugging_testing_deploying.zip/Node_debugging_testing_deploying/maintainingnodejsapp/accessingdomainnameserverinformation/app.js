console.log("Creating A DNS lookup Application");

var dns = require('dns');

// Lookup method
/*
dns.lookup('www.google.com',4,function(err,addresses) { // 2nd arg : 6 for IPV6 - Use 4 for IPV4
	
	if(err) throw err;
	
	console.log(addresses);
	
});
*/

// Resolve method
/*
dns.resolve('www.google.com','AAAA', function(err,addresses) { // 2nd arg : A for IPV4, AAAA for IPV6

	if(err) throw err;
	
	console.log(addresses);

});
*/

// Reverse method : To find the domain associated w/ an IP addresses
dns.reverse('74.125.225.18','AAAA', function(err,domains) { // 2nd arg : A for IPV4, AAAA for IPV6

	if(err) throw err;
	
	console.log(domains);

});