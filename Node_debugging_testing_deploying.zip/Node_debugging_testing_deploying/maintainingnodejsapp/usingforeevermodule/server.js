console.log("Using the forever Module");

var express = require('express');

var app = express();

app.get('/', function(req,res) {
	console.log("Some stdout output from our file");
	res.end("Welcome to the homepage");
});

var port=3456;
app.listen(port, function() {
	console.log("Server is listening on port : " + port);
	console.log("Process ID is : " + process.pid);
});