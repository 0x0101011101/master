﻿1/ Forever module can allow to monitor et restart automatically your node app
2/ Installation : npm install -g forever
3/ Kill node in task manager
4/ Start the app w/ forever : forever server.js
> Create 1 process for server.js
> Create 1 process forever who watch at server.js process
5/ Kill process server.js
6/ Relaunch automatically