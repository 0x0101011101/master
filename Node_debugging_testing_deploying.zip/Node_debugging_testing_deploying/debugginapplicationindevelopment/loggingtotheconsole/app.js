console.log("Logging to the console");

// Loading required module
var fs = require('fs');

// Print log
console.log("Loggin information to the console");
console.info("Printing to stdout using info function");

// Print Error
console.warn("This is a warning message");
console.error("This is a error message");

// In the console, to redirect error/warn message to a file
// node app.js 2> myError.log

// Print the stack
console.trace("customTrace");

// Timeout
var count = 0;
var interval = setInterval(function() {

	if(count == 0) {
		//start time
		console.time("ConsoleTimer");
	}

	if (count == 5) {
		console.timeEnd("ConsoleTimer");
		clearInterval(interval);
	}
	
	count++;
	console.log(count);
	
},1000);