// Debugger accessible on Port 5858
console.log("Using the Node debugger");

var count = 0;

/*
setInterval(function(){

	count++;
	console.log("Hi from the interval callback : We are at count :" + count);
	
	if(count%5 == 0) { 
		debugger; // Implementation of a breakpoint
	}

},1000);
*/

// To test : node debug app.js & type cont to go to the breakpoint - Use pause cmd to pause

var firstName="John";
var lastName="Doe";
debugger;
var lastName="Smith";

console.log("End of program");

// To see firstname value, type watch("firstName"); + watchers (an array)

// Go next: use next 