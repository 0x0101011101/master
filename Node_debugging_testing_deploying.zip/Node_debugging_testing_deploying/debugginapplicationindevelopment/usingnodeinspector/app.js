// To install node inspector : npm install -g node -inspector
// To launch in debud mode : node --debug app.js
console.log("Using Node Inspector");

var count=0;
var firstName="John";
var lastName="Doe";

var intervalObject = setInterval(function() {

	count++;
	console.log("Log message from app : " + count);
	
	if(count == 10) {
		console.log("Continuing App");
		clearInterval(intervalObject);
		continueApp(firstName,lastName);
	}
},1000);

function continueApp() {
	console.log("Timeout complete, Welcome %s %s", firstName, lastName);
}