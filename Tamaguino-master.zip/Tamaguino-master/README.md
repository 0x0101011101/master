# Tamaguino
Tamagotchi clone for Arduino

https://alojzjakob.github.io/Tamaguino/

[![ko-fi](https://www.ko-fi.com/img/donate_sm.png)](https://ko-fi.com/A654MLL)
