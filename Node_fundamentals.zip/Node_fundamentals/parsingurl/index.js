console.log("Parsing Urls");

var url = require('url');

var testUrl = "http://john:7654321@localhost:3456/path/to/resource?resourceId=someValue&resourceType=someType";

var parsedUrlObject = url.parse(testUrl,true);

console.log(parsedUrlObject);

var urlString = url.format(parsedUrlObject);

console.log('Url : ' + urlString);
