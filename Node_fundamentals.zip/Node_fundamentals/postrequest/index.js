// Import usefull module
var http = require('http');
var connect = require('connect');
var bodyParser = require('body-parser');

var app = connect()
	.use(bodyParser.urlencoded(
		{extended:true}
	))
	.use(function(req,res) {
		
		// Declare object to parse
		var parsedInfo = {};
		
		// Populate it
		parsedInfo.firstName = req.body.userFirstName;
		parsedInfo.lastName = req.body.userLastName;
		
		// Return response w/ data
		res.end("User info parsed info form : " + parsedInfo.firstName + " " + parsedInfo.lastName)
	
	});
	
// Creating Server
var port = 3456;
http.createServer(app).listen(port);

// For testing
console.log("Listening on port : " + port);
