// Import Connect module
var connect = require('Connect');

// Port number
var port = 3456;

var app = connect()
	.use(function(req,res){ // Handle the request
	
		if(req.url == "/hello") {
			console.log("Sending plain");
			res.end("Hello from app");
			
		} else if(req.url == "/hello.json") {
			console.log("Sending Json");
			var data = "Hello";
			var jsonData = JSON.stringify(data);
			res.setHeader('Content-Type', 'application/json');
			res.end(jsonData);
			
		} else if(req.url == "/statusCodeDemo") {
			console.log("Sending 404 status code");
			res.statusCode = 404;
			res.end("Oops, could not find something");
		}
	})
	.listen(port);

console.log("Listening on port :" + port);