// For testing
console.log("Serving Static Files");

// Import connect & serve-static module
var connect = require ('connect');
var serveStatic = require ('serve-static');

// Port number
var port = 3456;

// Create app
var app = connect()
	.use(serveStatic('myPublicFolder'))
	.use(function(req,res) {
		res.end("Welcome to our demo app");
	})
	.listen(port);

console.log("Listening on port 3456");
