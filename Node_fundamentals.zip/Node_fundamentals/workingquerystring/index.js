console.log("Working with Query String");

var queryString = require('queryString');

var testBaseUrl = "http://localhost:3456/path/to/resource";

var queryDataObject = {
	'resourceID': '1',
	'userName': 'Christophe'
}

var stringFromObject = queryString.stringify(queryDataObject,";",":"); // 2nd & 3rd arg to change querystring format

console.log(testBaseUrl + "?" + stringFromObject);
