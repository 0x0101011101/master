console.log("handling Web Server Events");

var http = require('http');
var server = http.createServer();
var port = 3456;

// Listening http request from a client
server.on('request', function(req,res) {
	console.log("Request received", req.headers);
	res.end("Thanks, I got your request");
});

// Listen to the upgrade event
server.on('upgrade', function(req,socket,head) {
	console.log("Upgrade the connection to a web socket connection");
	// Using third-party module on of HTTP
	
	
});

server.listen(port, function() {
	console.log("HTTP Server Listening");
});

