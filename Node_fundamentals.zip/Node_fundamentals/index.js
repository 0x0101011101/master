console.log ("A single Node Application");

// require and exports

var myModule = require('./sample_module.js');

//console.log(myModule.firstName);

//console.log(myModule.randomNum());

console.log(myModule());