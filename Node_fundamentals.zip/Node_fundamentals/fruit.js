// The module is visible by others
module.exports = function(myName, myDescription) {
	
	var name = myName;
	var description = myDescription;

	var functions = {
		setName: function(nameIn) {
			this.name = nameIn;
		},
		setDecription: function(descriptionIn) {
			this.description = descriptionIn;
		},
		getInfo: function() {
			return {
				name: name,
				description: description
			}
		}
	};
	
	return functions;
}