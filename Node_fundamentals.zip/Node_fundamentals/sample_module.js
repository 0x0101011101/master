// console.log ("A single Module");

/*
exports.firstName = "Andy";

exports.randomNum = function() {
	return Math.random();
}
*/

module.exports = function() {
	return Math.random();
}