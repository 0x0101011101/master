console.log("Core Modules");

var os = require('os'); // to load core module named os
// To edit os platform
// console.log(os.platform());

// http module (ex : create a server)
var http = require('http'); // to load core module named http
console.log(http);