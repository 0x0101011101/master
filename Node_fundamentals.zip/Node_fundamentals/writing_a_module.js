console.log("A simple node application");

/*
// Apple
var apple = require('./fruit.js'); // Loading custom module
console.log(apple().getInfo()); // Calling function object apple()

// Orange
var orange = require('./fruit')();
orange.setName('Orange');
console.log(orange.getInfo());
*/

var fruit = require('./fruit.js');

var apple = fruit('Apple','This is from an Apple tree'); // using fruit function
var orange = fruit('Orange', 'This is from an Orange tree');

console.log(apple.getInfo());
console.log(orange.getInfo());