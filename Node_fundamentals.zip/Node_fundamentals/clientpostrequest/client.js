var request = require ('request');
var fs = require ('fs');

var data = {
	userFirstName : "John",
	userLastName : "Doe",
	myBuffer: new Buffer([1]), // buffer for passing data
	myFile: fs.createReadStream(__dirname + '/images/npm.jpg') // read stream containing file data to pass
}

// Post request
//request.post('http://localhost:3456').form(data)
//request.post('http://localhost:3456',{form:data});

// Callback function
var callback = function(error, response, body) {
	if (error) console.log(error);
	else console.log(body);
}

//request.post('http://localhost:3456',{form:data}, callback);

request.post( 
	{url:'http:localhost:3456', formData:data}, function optionalCallback(err, body, response) {
		if (err) {
			return console.error('Uploading problem');
		}
		console.log('File uploaded to Server');
	});