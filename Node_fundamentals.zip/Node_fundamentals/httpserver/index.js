console.log("Basic HTTP Server");

// import http module
var http = require('http');

// Handler
var handlerMethod = function (req, res) {

	res.end("Response from Server");
	
}

// Create Server
var port = 3456;
var hostname = 'localhost';

http.createServer(handlerMethod).listen(port,hostname);

// For testing
console.log('Listen on : ' + hostname + ':' + port);



